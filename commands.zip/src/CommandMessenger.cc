//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "CommandMessenger.hh"

#include "PrimaryPart.hh"
#include "G4UIdirectory.hh"

#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "globals.hh"
using namespace std;
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CommandMessenger::CommandMessenger(PrimaryPart* pP):primaryPart(pP)
{
 this->f_messenger=primaryPart->f_prim;
 (*f_messenger) << "Hi from messenger!" << G4endl;
  primaryPartCommand = new G4UIdirectory("/PrimaryPart/");
  primaryPartCommand->SetGuidance("User Primary Particles commands");
  
  my_cmd = new G4UIcmdWithADoubleAndUnit("/PrimaryPart/my_cmd",this);
  my_cmd->SetGuidance("It's my command!");
  my_cmd->SetParameterName("Energy",true,true);
  my_cmd->SetDefaultValue(1.);  
  my_cmd->SetDefaultUnit("keV");
  my_cmd->SetUnitCandidates("ev keV MeV GeV TeV");
  my_cmd->SetRange("Energy != 0.");
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
CommandMessenger::~CommandMessenger()
{
 *(f_messenger)<<"Bye from messenger!" << G4endl;
 delete my_cmd;
 delete primaryPartCommand;
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CommandMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{      
 if (command == my_cmd)
 {
  (*f_messenger) << "command value before " << (this->GetCurrentValue(my_cmd)) << G4endl;
  this->primaryPart->GetParticleGun()->SetParticleEnergy(my_cmd->GetNewDoubleValue(newValue));
  (*f_messenger) << "command value after " << (this->GetCurrentValue(my_cmd)) << G4endl;
 }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4String CommandMessenger::GetCurrentValue(G4UIcommand* command)
{
 G4String cv;
 if (command==my_cmd)
 {
  cv=my_cmd->ConvertToString(this->primaryPart->GetParticleGun()->GetParticleEnergy(),"GeV");
 }
 return cv;
}
