#include <PrimaryPart.hh>

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 this->f_prim=&ofsa;
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart!" << G4endl;
 commandMessenger = new CommandMessenger(this);
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());
 GProton->SetParticleEnergy(100. * MeV);
// GNeutron = new G4ParticleGun(1);
// GNeutron->SetParticleDefinition(G4Neutron::NeutronDefinition()); 
}

PrimaryPart::~PrimaryPart() 
{
// (*f_prim) << "from messenger " << commandMessenger->GetCurrentValue(my_cmd) << G4endl;
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart!" << G4endl;
 delete commandMessenger;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
 //GProton->SetParticleEnergy(100. * MeV);
 GProton->SetParticlePosition(G4ThreeVector(0*mm , 0*mm, -21.*cm));
// GGamma->SetParticlePosition(G4ThreeVector(0, 0, 0));
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 GProton->GeneratePrimaryVertex(anEvent);
 
// GNeutron->SetParticleEnergy(14. * MeV);
// GNeutron->SetParticlePosition(G4ThreeVector(0*mm , 0*mm, -21.*cm));
// GNeutron->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
// GNeutron->GeneratePrimaryVertex(anEvent);
 
}
